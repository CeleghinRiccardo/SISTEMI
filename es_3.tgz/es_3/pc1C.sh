#!/bin/bash

ip address add 192.168.3.1/24 dev eth0
ip address add 2a00:0:0:c::10/64 dev eth0

ip route add default via 192.168.3.254
ip route add default via 2a00:0:0:c::1
