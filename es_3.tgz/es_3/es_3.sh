#!/bin/bash

clean

tmux kill-session -t debian-net

tmux new-session -d -s debian-net -n Console

tmux new-window -t debian-net -n pc1A "bash -c 'hstart pc1A lanA'"
tmux new-window -t debian-net -n rAB "bash -c 'rstart rAB lanA lanB'"
tmux new-window -t debian-net -n rBC "bash -c 'rstart rBC lanB lanC'"
tmux new-window -t debian-net -n pc1C "bash -c 'hstart pc1C lanC'"

echo "rete configurata!!!!!"


tmux attach -t debian-net
