#!/bin/bash

ip address add 192.168.1.254/24 dev eth0
ip address add 2a00:0:0:a::1/64 dev eth0
ip address add 192.168.2.254/24 dev eth1
ip address add 2a00:0:0:b::1/64 dev eth1

ip route add 192.168.3.0/24 via 192.168.2.253
ip route add 2a00:0:0:c::/64 via 2a00:0:0:b::2
